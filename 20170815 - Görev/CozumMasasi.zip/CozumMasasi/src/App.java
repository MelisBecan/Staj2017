import java.math.BigDecimal;

public class App {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Long a = 1L;
		
		System.out.println(a.compareTo(0L));
		System.out.println(a.compareTo(1L));
		System.out.println(a.compareTo(2L));
	}

}
