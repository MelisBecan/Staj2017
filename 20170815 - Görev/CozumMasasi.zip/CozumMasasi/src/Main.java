import java.sql.SQLException;

import Entity.Tag;
import Model.RemarksModel;
import Model.TagsModel;

public class Main {

	public static void main(String[] args) throws SQLException {

//		ProblemsModel islem = new ProblemsModel();
		
		TagsModel islem = new TagsModel();

		Tag r1=new Tag();
		
//		r1.setRemark("bir not");
//		 System.out.println(islem.readByID(9).getProblem());
		
//		islem.readByID(2);
		
		r1.setTag("deneme2");
		
//		islem.addTag(r1);
		if(!islem.isTagExist(r1)) {
			islem.addTag(r1);
		}
//		r1.setMarkID(2);
//		r1.setRemark("yeni");
//		islem.updateRemark(r1);
		
	}
}