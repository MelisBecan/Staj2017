import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.ArrayList;

import Controller.ProblemsController;
import Entity.Problem;

public class Main {

	public static void main(String[] args) throws SQLException {
		
		ProblemsController pc = new ProblemsController();

		ArrayList<Problem> result = pc.readAll();

		for (int i = 0; i < result.size(); i++) {
			System.out.println(result.get(i).getProblem());
		}
	}
}