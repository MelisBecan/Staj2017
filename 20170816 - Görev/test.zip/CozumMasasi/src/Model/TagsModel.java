package Model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import Entity.Problem;
import Entity.Tag;


public class TagsModel extends Model {

	public void addTag(Tag rmrk) throws SQLException {
		stmt = con.prepareStatement("INSERT INTO tags VALUE(NULL,?)");
		stmt.setString(1, rmrk.getTag());
		int rs = stmt.executeUpdate();
		System.out.println("Tag eklendi");
	}

	public void updateTag(Tag rmrk) throws SQLException {
		stmt = con.prepareStatement("UPDATE tags SET tag=? WHERE TagID=?");
		stmt.setString(1, rmrk.getTag());
		stmt.setInt(2, rmrk.getTagID());
		int rs = stmt.executeUpdate();
		System.out.println("Tag guncellendi");
	}

	public void deleteTag(int id) throws SQLException {
		stmt = con.prepareStatement("Delete FROM tags WHERE TagID=?");
		stmt.setInt(1, id);
		int rs = stmt.executeUpdate();
		System.out.println("Tag silindi");
	}

	public ArrayList<Tag> readByID(int id) throws SQLException {
		ArrayList<Tag> liste2 = new ArrayList();
		stmt = con.prepareStatement("SELECT * FROM tags WHERE TagID=?");
		stmt.setInt(1, id);
		ResultSet rs = stmt.executeQuery();

		while (rs.next()) {
			Tag tag = new Tag();
			tag.setTagID(rs.getInt("TagID"));
			tag.setTag(rs.getString("tag"));
			liste2.add(tag);
		}

		for (int i = 0; i < liste2.size(); i++) {
			System.out.println(liste2.get(i).getTag());
		}

		return liste2;
	}

	public boolean isTagExist(Tag rmrk) throws SQLException {

		boolean result = false;

		PreparedStatement stmt;
		int kontrol = 0;
		stmt = con.prepareStatement("SELECT COUNT(*) FROM tags WHERE tag=?");
		stmt.setString(1, rmrk.getTag());
		ResultSet rs = stmt.executeQuery();

		while (rs.next()) {
			kontrol = rs.getInt(1);
			if (kontrol > 0) {
				result = true;
			}
		}
		return result;
	}
	
	public ArrayList<Problem> getProblemsByHashtag(Tag tagdeger) throws SQLException {
		ArrayList<Problem> hashtaglist = new ArrayList();
		
		stmt=con.prepareStatement("SELECT * FROM tagproblems INNER JOIN problems ON tagproblems.ProbID=problems.ProbID WHERE tagproblems.TagID=(SELECT tagID FROM tags WHERE tag=?)");
		stmt.setString(1, tagdeger.getTag());
		ResultSet rs=stmt.executeQuery();
		
		while(rs.next()) {
			Problem prblm=new Problem();
			prblm.setProblem(rs.getString("problem"));
			hashtaglist.add(prblm);
		}
		
		for (int i = 0; i < hashtaglist.size(); i++) {
			System.out.println(hashtaglist.get(i).getProblem());
		}

		return hashtaglist;
	}
}
