package Controller;

import java.util.ArrayList;

import Entity.Problem;
import Model.ProblemsModel;

public class ProblemsController extends Controller {
	
	public ProblemsModel pm = new ProblemsModel();
	
	
	public ArrayList<Problem> readAll() {
		
		return pm.readAll();
	}
	
}
