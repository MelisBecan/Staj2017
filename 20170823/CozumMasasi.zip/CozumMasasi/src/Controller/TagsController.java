package Controller;

import java.util.ArrayList;

import Entity.Tag;
import Model.TagsModel;

public class TagsController extends Controller {
	TagsModel tm = new TagsModel();
	
	public ArrayList<Tag> readlast() {
		return tm.readlast();
	}
	
	public ArrayList<Tag> resulttagID(int id) {
		return tm.resulttagID(id);
	}
	
}
