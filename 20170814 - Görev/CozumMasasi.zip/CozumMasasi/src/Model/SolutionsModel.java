package Model;

public class SolutionsModel extends Model {

}
