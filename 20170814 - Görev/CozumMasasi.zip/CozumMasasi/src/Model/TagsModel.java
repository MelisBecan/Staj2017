package Model;

public class TagsModel extends Model {

}
