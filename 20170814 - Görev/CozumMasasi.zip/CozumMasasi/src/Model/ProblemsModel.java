package Model;

import java.sql.Date;

public class ProblemsModel extends Model {

}
