package Model;

import java.sql.Connection;

public class Model {
	Connection con;
	public Model(){
		
	}
}
