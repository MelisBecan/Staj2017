package Model;

public class RemarksModel extends Model {

}
