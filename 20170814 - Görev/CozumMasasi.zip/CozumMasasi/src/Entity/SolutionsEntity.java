package Entity;

public class SolutionsEntity {
	int SolutionsID;
	String solution;
	
	public int getSolutionsID() {
		return SolutionsID;
	}
	public void setSolutionsID(int solutionsID) {
		SolutionsID = solutionsID;
	}
	public String getSolution() {
		return solution;
	}
	public void setSolution(String solution) {
		this.solution = solution;
	}
}
