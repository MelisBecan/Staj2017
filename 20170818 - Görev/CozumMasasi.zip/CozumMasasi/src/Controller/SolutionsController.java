package Controller;

import java.sql.SQLException;
import java.util.ArrayList;

import Entity.Solution;
import Model.SolutionsModel;

public class SolutionsController extends Controller {

	SolutionsModel sm=new SolutionsModel();
	
	public ArrayList<Solution> readByID(int id) {
		try {
			return sm.readByID(id);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}
}
