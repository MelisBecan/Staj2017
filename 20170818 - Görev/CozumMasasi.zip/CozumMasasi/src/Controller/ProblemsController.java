package Controller;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;

import Entity.Problem;
import Model.ProblemsModel;

public class ProblemsController extends Controller {
	
	public ProblemsModel pm = new ProblemsModel();
	
	
	public ArrayList<Problem> readAll() {
		return pm.readAll();
	}
	
	public ArrayList<Problem> readlast() {
		return pm.readlast();
	}
	
	public HashMap<String,Integer> statisticErrors() {
		return pm.statisticErrors();
	}
	
	public Problem readByID(int id) {
		try {
			return pm.readByID(id);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}
	
}
