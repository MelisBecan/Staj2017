package Controller;

import java.sql.SQLException;
import java.util.ArrayList;

import Entity.Remark;
import Model.RemarksModel;

public class RemarksController extends Controller {

	RemarksModel rm=new RemarksModel();
	
	public ArrayList<Remark> readByID(int id) {
		try {
			return rm.readByID(id);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}
	
}
